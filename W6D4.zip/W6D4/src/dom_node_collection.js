class DomNodeCollection {
    constructor(arr) {
        this.arr = arr;
    }

    html(str) {
        if (str) {this.arr.forEach(el => {
            el.innerHTML = str;});}
        else {return this.arr[0].innerHTML;}
    }

    empty() {
        this.arr.forEach(el => {
            el.innerHTML = "";
        });
    }

    append(arg) {
        for (let i=0; i<this.arr.length; i++) {
            this.arr[i].innerHTML.append(arg[i].outerHMTL);
        }
    }

    attr(name) {
        return this.arr[0].attributes[name];
    }

    addClass(className) {
        this.arr.forEach(el =>{
            el.classList.add(className);
        });}

    removeClass(className) {
        this.arr.forEach(el => {
        el.classList.remove(className);
    });}

    children(){
        let childArr = [];
        this.arr.forEach(el =>{
            childArr.push(el.children);
        });
        return new DomNodeCollection(childArr);
    }

    parent(){
        let parentArr = [];
        this.arr.forEach(el =>{
            parentArr.push(el.parentNode);
        });
        return new DomNodeCollection(parentArr);
    }

    find(selector){
        let results = document.querySelectorAll(selector);
        return new DomNodeCollection(results);
    }

    remove(){
        this.arr.forEach(ele => {
            ele.parentNode.removeChild(ele);
        });
    }


}

module.exports = DomNodeCollection;