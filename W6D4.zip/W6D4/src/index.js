const DomNodeCollection = require("./dom_node_collection.js");

window.$l = function(arg){
    if (arg instanceof HTMLElement) {
        return new DomNodeCollection([arg]);
    }
    let ele = document.querySelectorAll(arg);
    return new DomNodeCollection(Array.from(ele));
};

