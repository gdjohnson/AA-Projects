const View = require('./ttt-view.js');
const Game = require('./game.js');


//loads when all DOMC is loaded.
  $(() => {
    const game = new Game();
    const view = new View(game, $('.ttt'));
  });