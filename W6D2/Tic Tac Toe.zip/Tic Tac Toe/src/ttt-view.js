class View {
  constructor(game, $el) {
    this.game = game;
    this.grid = $el;
    this.grid.append(this.setupBoard());
    this.bindEvents();
  }

  bindEvents() {
    $('ul').on('click', 'li', (event) => {
      // debugger
      this.makeMove($(event.target));
      this.game.playMove($(event.target).data('position'));
      if (this.game.isOver()) {
        let winner = this.game.winner();
        $("#Winner").text(`You Won, ${winner}`);
      }
    });
  }

  makeMove($square) {
    // debugger
    
    let player = this.game.currentPlayer;
    $square.addClass(player);
    let $p = $(`<p>${player}</p>`);
    $square.text(player);



  }

  setupBoard() {
    const $ul = $('<ul></ul>');
    let i = 0;

    while(i < 3){
      let j = 0;
      while(j < 3){
        let $li = $('<li>');
        $li.data({position: [i, j]});
        $ul.append($li);
        j++;
      }
      i++;
    }
    $ul.addClass("group");
    return $ul;
  }
}

module.exports = View;
