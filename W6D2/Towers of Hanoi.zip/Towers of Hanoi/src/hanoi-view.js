class View{
    constructor(game, $el){
        this.game = game;
        this.board = $el;
        this.board.append(this.setupTowers());
        this.board.append(this.setupTowers());
        this.board.append(this.setupTowers());
        this.render();
        
    }

    clickTower(){
        $startpos = $('li').on('click', (event) =>{return event.target;});
        $endpos = 
    }

    setupTowers(){
        let $ul = $('<ul></ul>');
        let i = 0;
        while (i < 3){
            let $li = $('<li></li>');
            $ul.append($li);
            i++;
        }
        return $ul;
    }

    render(){

    }
}

module.exports = View;